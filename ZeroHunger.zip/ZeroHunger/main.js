const express = require("express");
const session = require("express-session");
const mongoose = require("mongoose");

const app = express();
const port = 3000;
const path = require("path");
const collection = require("./mongoose");

app.use(express.json());
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "/views"));
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));

// Set up session middleware
app.use(
    session({
        secret: "your-secret-key",
        resave: true,
        saveUninitialized: true,
    })
);

// Middleware to check if the user is logged in
app.use((req, res, next) => {
    if (req.session.userId) {
        res.locals.user = req.session.userId;
    }
    next();
});

// Middleware to check if the user is authenticated
const isAuthenticated = (req, res, next) => {
    if (res.locals.user) {
        next();
    } else {
        res.redirect("/actual");
    }
};

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

// Render signup page
app.get("/signup", (req, res) => {
    res.render("signup.ejs");
});

//Render actual page
// app.get("/actual", (req, res) => {
//     res.render("actual.ejs");
// });

// Render login page
app.get("/login", (req, res) => {
    res.render("login.ejs");
});

// Handle signup form submission
app.post("/signup", async (req, res) => {
    const data = {
        name: req.body.name,
        email: req.body.email,
        number: req.body.number,
        password: req.body.password,
    };

    // Check if email already exists
    const existingEmail = await collection.LoginData.find({ email: req.body.email });

    if (existingEmail.length > 0) {
        req.body.email = "";
        console.log("Email already exists");
        res.render("signup.ejs", { error: "Email already exists" });
        return;
    }

    // Check if password already exists
    const existingPassword = await collection.LoginData.find({ password: req.body.password });

    if (existingPassword.length > 0) {
        req.body.password = "";
        console.log("Password already exists");
        res.render("signup.ejs", { error: "Password already exists" });
        return;
    }

    // If email and password are unique, insert into the collection
    try {
        await collection.LoginData.create(data);
        res.redirect("/login");
    } catch (error) {
        console.error("Error during signup:", error);
        res.render("signup.ejs", { error: "Error during signup" });
    }
});

// Render home page or redirect to actual page if the user is logged in
app.get("/", (req, res) => {
    if (res.locals.user) {
        res.redirect("/actual");
    } else {
        res.render("home.ejs");
    }
});


// ... (existing code)

app.get("/data", async (req, res) => {
    try {
        // Fetch data from /actual route
        const foodRequests1 = await collection.FoodData.find();

        // Fetch data from /actual/request route
        
        // Render the data.ejs template with the fetched data
        res.render("alldata.ejs", { foodRequests1 });
    } catch (err) {
        console.error("Error fetching data:", err);
        res.status(500).send("Error fetching data");
    }
});

// ... (existing code)

// Modified /connect route
// app.get("/connect", isAuthenticated, async (req, res) => {
//     try {
//         const user = await collection.LoginData.findById(res.locals.user);
//         if (user) {
//             res.render("actual.ejs", { username: user.name });
//         } else {
//             console.error("User not found");
//             res.redirect("/login");
//         }
//     } catch (error) {
//         console.error("Error retrieving user:", error);
//         res.redirect("/login");
//     }
// });

// Handle login form submission
app.post("/login", async (req, res) => {
    try {
        const check = await collection.LoginData.findOne({ email: req.body.email });

        if (check && check.password === req.body.password) {
            req.session.userId = check._id;
            res.redirect("/data");
        } else {
            req.body.password = "";
            console.log("Wrong email or password");
            res.render("login.ejs", { error: "Wrong email or password" });
        }
    } catch (error) {
        console.error("Error during login:", error);
        res.render("login.ejs", { error: "Error during login" });
    }
});

// Render request form
app.get("/data/request", (req, res) => {
    res.render("request.ejs");
});

// Handle request form submission
app.post("/data/request", isAuthenticated, async (req, res) => {
    const data1 = {
        name: req.body.name,
        PN: req.body.numPeople,
        type: req.body.foodType,
        address: req.body.address,
    };

    console.log(data1);
    try {
        // Create a new instance of the FoodData model and save it to the database
        const foodRequest = new collection.FoodData(data1);
        console.log(foodRequest);
       
        await foodRequest.save();

        res.redirect("/data");
    } catch (error) {
        console.error("Error saving food request:", error);
        res.render("error.ejs", { error: "Error saving food request" });
    }
});
app.get("/actual", (req, res) => {
    res.redirect("/data");
  });
  