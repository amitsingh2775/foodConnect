const mongoose = require("mongoose");

mongoose.connect('mongodb://127.0.0.1:27017/userdata')
  .then(() => {
    console.log("mongodb connected");
  })
  .catch((error) => {
    console.log(`not connected due to ${error}`);
  });

const LoginSchema = new mongoose.Schema({
  name: {
    type: String,
  },
  email: {
    type: String,
  },
  number: {
    type: Number,
  },
  password: {
    type: String,
  }
});

const FoodRequestSchema = new mongoose.Schema({
  name: {
    type: String,
  },
  PN: {
    type: Number,
  },
  type: {
    type: String,
  },
  address: {
    type: String,
  }
});

const LoginData = mongoose.model("LoginData", LoginSchema);
const FoodData = mongoose.model("FoodData", FoodRequestSchema);

module.exports = { LoginData, FoodData };
